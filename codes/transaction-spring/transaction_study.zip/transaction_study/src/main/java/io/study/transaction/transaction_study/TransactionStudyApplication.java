package io.study.transaction.transaction_study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionStudyApplication.class, args);
	}

}
