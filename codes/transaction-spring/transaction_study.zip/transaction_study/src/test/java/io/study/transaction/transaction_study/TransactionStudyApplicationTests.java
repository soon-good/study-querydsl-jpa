package io.study.transaction.transaction_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
